export class UserEntity {
  id: string;
  name: string;
  email: string | null;
  dni: string | null;
  password: string | null;
  educationLevel: string | null;
  hireDate: Date | null;
  role: string;
  status: string;
  projectId: string | null;
  areaId: string | null;
  createdAt: Date;
  updatedAt: Date;

  /**
   * Campos por los que se puede ordenar.
   * Cualquier campo fuera de esta lista es ignorado silenciosamente.
   */
  static readonly SORTABLE_FIELDS: (keyof UserEntity)[] = [
    'name',
    'email',
    'id',
    'hireDate',
    'role',
    'status',
    'createdAt',
  ];

  /**
   * Campos sobre los que se pueden aplicar filtros dinámicos.
   * Actúa como whitelist de seguridad — nunca exponer campos sensibles.
   */
  static readonly FILTERABLE_FIELDS: (keyof UserEntity)[] = [
    'name',
    'email',
    'status',
    'role',
    'projectId',
    'areaId',
    'dni',
  ];

  /** Campos sobre los que aplica el ?search= global */
  static readonly SEARCH_FIELDS: (keyof UserEntity)[] = [
    'name',
    'email',
    'dni',
    'projectId',
  ];

  /**
   * Campos que se retornan por defecto en los listados.
   * Útil para un futuro select dinámico.
   */
  static readonly DEFAULT_SELECT = {
    id: true,
    name: true,
    email: true,
    dni: true,
    educationLevel: true,
    hireDate: true,
    role: true,
    status: true,
    createdAt: true,
    updatedAt: true,
    project: {
      select: {
        id: true,
        name: true,
        status: true,
      },
    },
    area: {
      select: {
        id: true,
        name: true,
        status: true,
      },
    },
  } as const;
}
