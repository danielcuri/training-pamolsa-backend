import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { AuthModule } from './auth/auth.module';
import { JwtAuthGuard } from './auth/guards/jwt-auth.guard';
import { RolesGuard } from './auth/guards/roles.guard';
import { PrismaModule } from './prisma/prisma.module';
import { ProjectModule } from './project/project.module';
import { AreaModule } from './area/area.module';
import { OperationModule } from './operation/operation.module';
import { UserModule } from './user/user.module';
import { TrainingTemplateModule } from './training-template/training-template.module';
import { TemplateOperationModule } from './template-operation/template-operation.module';
import { TrainingModule } from './training/training.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    AuthModule,
    ProjectModule,
    AreaModule,
    OperationModule,
    UserModule,
    TrainingTemplateModule,
    TemplateOperationModule,
    TrainingModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
})
export class AppModule {}
